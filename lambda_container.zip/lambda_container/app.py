import json
import boto3
import joblib
import os

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

MODEL_BUCKET = "telco-churn-model-ml-001"
MODEL_KEY = "models/churn_model.joblib"
TABLE_NAME = "churn_feature_store"

LOCAL_MODEL_PATH = "/tmp/churn_model.joblib"

def load_model():
    if not os.path.exists(LOCAL_MODEL_PATH):
        s3.download_file(MODEL_BUCKET, MODEL_KEY, LOCAL_MODEL_PATH)
    return joblib.load(LOCAL_MODEL_PATH)

model = load_model()
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    customer_id = event.get("customer_id")

    if not customer_id:
        return {"statusCode": 400, "body": "customer_id is required"}

    response = table.get_item(Key={"customer_id": customer_id})

    if "Item" not in response:
        return {"statusCode": 404, "body": "Customer not found"}

    item = response["Item"]

    features = [[
        float(item["tenure_months"]),
        float(item["monthly_charges"]),
        float(item["total_charges"]),
        float(item["churn_score"]),
        float(item["cltv"])
    ]]

    prediction = model.predict(features)[0]
    probability = model.predict_proba(features)[0][1]

    return {
        "statusCode": 200,
        "body": json.dumps({
            "customer_id": customer_id,
            "churn_prediction": int(prediction),
            "churn_probability": probability
        })
    }
